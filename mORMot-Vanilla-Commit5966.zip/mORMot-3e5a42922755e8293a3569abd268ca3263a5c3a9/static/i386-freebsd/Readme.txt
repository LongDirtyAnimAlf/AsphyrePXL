Currently no static file is available for this target.

Please use an external .so for the SQLite3 engine.