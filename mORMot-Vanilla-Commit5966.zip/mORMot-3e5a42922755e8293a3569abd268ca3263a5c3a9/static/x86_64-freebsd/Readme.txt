Currently no static file is available for this target.

Please use an external .so for the SQLite3 engine.

pkg install gcc
pkg install os-generic-userland-devtools
pkg install os-generic-userland-lib32 os-generic-userland-lib32-development