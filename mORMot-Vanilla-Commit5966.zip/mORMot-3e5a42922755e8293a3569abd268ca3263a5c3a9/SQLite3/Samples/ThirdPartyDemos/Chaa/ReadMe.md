SSPI / Windows Authentication Test App for *mORMot*
===================================================

*by Chaa*


This is some code shared in our forum, at http://synopse.info/forum/viewtopic.php?pid=17358#p17358

Could be used to validate that the SSPI authentication works as expected on your platform.

Thanks Chaa for sharing!