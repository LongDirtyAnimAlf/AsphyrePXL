#!/bin/bash

GitCommit.sh
GitCommitDMustache.sh
GitCommitLVCL.sh
GitCommitSynPdf.sh
GitCommitSynProject.sh
